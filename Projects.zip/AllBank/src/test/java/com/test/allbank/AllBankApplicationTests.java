package com.test.allbank;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AllBankApplicationTests {

    @Test
    void contextLoads() {
    }

}
