package com.test.allbank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AllBankApplication {

    public static void main(String[] args) {
        SpringApplication.run(AllBankApplication.class, args);
    }

}
