package com.test.oauthaccount;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OauthAccountApplicationTests {

    @Test
    void contextLoads() {
    }

}
